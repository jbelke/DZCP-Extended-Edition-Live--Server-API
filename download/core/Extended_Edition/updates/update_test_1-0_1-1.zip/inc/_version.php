<?php
/**
 * <DZCP-Extended Edition>
 * @package: DZCP-Extended Edition
 * @author: DZCP Developer Team || Hammermaps.de Developer Team
 * @link: http://www.dzcp.de || http://www.hammermaps.de
 */

define('_version', '1.1');
define('_release', '31.08.2013');
define('_build', 'repo:dev:git:0176');
define('_edition', 'Extended Edition');